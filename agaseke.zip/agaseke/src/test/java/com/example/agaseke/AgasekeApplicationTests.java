package com.example.agaseke;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgasekeApplicationTests {

    @Test
    void contextLoads() {
    }

}
