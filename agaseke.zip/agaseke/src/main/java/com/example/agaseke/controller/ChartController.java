package com.example.agaseke.controller;

import com.example.agaseke.enums.EStatus;
import com.example.agaseke.service.inter.ForumInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
@RestController
public class ChartController {

    @Autowired
    ForumInterface forumService;

    @GetMapping("/forums/stats")
    public java.util.Map<String, Long> getForumStats() {
        long pending = forumService.countByStatus(EStatus.PENDING);
        long approved = forumService.countByStatus(EStatus.APPROVED);
        long denied = forumService.countByStatus(EStatus.DENIED);

        Map<String, Long> stats = new HashMap<>();
        stats.put("pending", pending);
        stats.put("approved", approved);
        stats.put("denied", denied);

        return stats;
    }
}
