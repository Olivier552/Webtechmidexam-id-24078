package com.example.agaseke.model;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private String content;
//    @ManyToOne
//    private User userID;
    @ManyToOne
    private Forum forum;
    @CreationTimestamp
    private Date createdDate;


}
