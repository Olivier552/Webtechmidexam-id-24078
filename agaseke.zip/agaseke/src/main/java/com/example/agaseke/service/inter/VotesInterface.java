package com.example.agaseke.service.inter;

import com.example.agaseke.model.Votes;

import java.util.List;

public interface VotesInterface {
    public List<Votes> getAllVote();
    public void saveVotes();

}
