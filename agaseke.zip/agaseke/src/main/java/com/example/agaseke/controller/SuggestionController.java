package com.example.agaseke.controller;

import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Suggestion;
import com.example.agaseke.repository.SuggestionRepository;
import com.example.agaseke.service.inter.SuggestionInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@Controller
@RequestMapping("/suggestions")
public class SuggestionController {

    @Autowired
    private SuggestionInterface suggestionService;

    @Autowired
    private SuggestionRepository suggestionRepository;

    @GetMapping
    public String getAllSuggestionss(
            @RequestParam(required = false) String title,
            Pageable pageable,
            Model model) {
        Page<Suggestion> suggestionPage = suggestionService.getAllSuggestions(title, pageable);
        model.addAttribute("suggestions", suggestionPage.getContent());
        model.addAttribute("page", suggestionPage);
        return "suggestions/list";  // Changed view name to "suggestions-list"
    }

    @GetMapping("/{id}")
    public String getAllSuggestions(
            @RequestParam(required = false) String title,
            @PathVariable("id")Comment comment,
            Pageable pageable,
            Model model) {
        Page<Suggestion> suggestionPage = suggestionService.getSuggestionsByComment(comment, pageable);
        model.addAttribute("suggestions", suggestionPage.getContent());
        model.addAttribute("page", suggestionPage);
        model.addAttribute("comment", comment);
        return "suggestions/comment-suggestion";  // Changed view name to "suggestions-list"
    }

    @GetMapping("/new/{id}")
    public String showNewSuggestionForm(Model model,
                                        @PathVariable("id") Comment commentId) {
        model.addAttribute("suggestion", new Suggestion());
        model.addAttribute("commentId", commentId);
        return "suggestions/form";
    }

    @PostMapping("/save")
    public String saveSuggestion(@RequestParam Comment commentId,
            @ModelAttribute("suggestion") Suggestion suggestion) {
        suggestion.setComment(commentId);
        suggestionService.saveSuggestion(suggestion);
        return "redirect:/suggestions";
    }

    @GetMapping("/edit/{id}")
    public String showEditSuggestionForm(@PathVariable("id") UUID id, Model model) {
        Suggestion suggestion = suggestionService.getSuggestionById(id);
        if (suggestion != null) {
            model.addAttribute("suggestion", suggestion);
            return "suggestions/form";
        } else {
            return "redirect:/suggestions";
        }
    }

    @PostMapping("/update/{id}")
    public String updateSuggestion(@PathVariable("id") UUID id, @ModelAttribute("suggestion") Suggestion suggestion) {
        suggestion.setSuggestionID(id);
        suggestionService.updateSuggestion(suggestion);
        return "redirect:/suggestions";
    }

    @GetMapping("/delete/{id}")
    public String deleteSuggestion(@PathVariable("id") UUID id) {
        suggestionService.deleteSuggestion(id);
        return "redirect:/suggestions";
    }
    @PostMapping("/vote/{id}")
    public String voteForIdea(@PathVariable("id")UUID id,
                              @RequestParam String voteValue){
        Suggestion suggestion = suggestionService.getSuggestionById(id);

        return "redirect:suggestions/{id}";
    }

}
