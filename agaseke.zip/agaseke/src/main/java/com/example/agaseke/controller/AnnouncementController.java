package com.example.agaseke.controller;

import com.example.agaseke.model.Announcement;
import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Announcement;
import com.example.agaseke.model.Forum;
import com.example.agaseke.repository.AnnouncementRepository;
import com.example.agaseke.service.inter.AnnouncementInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/announcement")
public class AnnouncementController {
    @Autowired
    private AnnouncementInterface announcementInterface;

    @GetMapping("/home")
    public String showAnnouncement(Model model) {
        List<Announcement> announcement = announcementInterface.getListOfAnnouncements();
        model.addAttribute("announcement", announcement);
        model.addAttribute("forum", new Forum());
        return "announcements/home";
    }
    @GetMapping
    public String getAllAnnouncements(
            @RequestParam(required = false) String title,
            Pageable pageable,
            Model model) {
        Page<Announcement> announcementPage = announcementInterface.getAllAnnouncements(title, pageable);
        model.addAttribute("announcement", announcementPage.getContent());
        model.addAttribute("announcements", new Announcement());
        model.addAttribute("page", announcementPage);
        return "announcements/list";  // Changed view name to "announcement-list"
    }

    @GetMapping("/new")
    public String showNewAnnouncementForm(Model model) {
        List<Announcement> announcement = announcementInterface.getAnnouncementsOneWeekOld();
        model.addAttribute("announcement", announcement);
        return "announcements/new-form";
    }

    @PostMapping("/save")
    public String saveAnnouncement(
                                 @ModelAttribute("announcement") Announcement announcement) {
        announcement.setPublishDate(LocalDateTime.now());
        announcementInterface.saveAnnouncement(announcement);
        return "redirect:/announcement";
    }

    @GetMapping("/edit/{id}")
    public String showEditAnnouncementForm(@PathVariable("id") UUID id, Model model) {
        Announcement announcement = announcementInterface.getAnnouncementById(id);
        if (announcement != null) {
            model.addAttribute("announcement", announcement);
            return "announcements/form";
        } else {
            return "redirect:/announcement";
        }
    }

    @PostMapping("/update/{id}")
    public String updateAnnouncement(@PathVariable("id") UUID id,
            @PathVariable("publishedDate")LocalDateTime publishDate
            , @ModelAttribute("announcement") Announcement announcement) {
        announcement.setId(id);
        announcement.setPublishDate(LocalDateTime.now());
        announcementInterface.updateAnnouncement(announcement);
        System.out.println("The published Date is "+publishDate);
        return "redirect:/announcement";
    }

    @GetMapping("/delete/{id}")
    public String deleteAnnouncement(@PathVariable("id") UUID id) {
        announcementInterface.deleteAnnouncement(id);
        return "redirect:/announcement";
    }
}
