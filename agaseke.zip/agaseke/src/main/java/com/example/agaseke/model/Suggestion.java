package com.example.agaseke.model;

import lombok.Data;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;
import java.util.UUID;

@Data
@Entity
public class Suggestion {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID suggestionID;

    private String content;

    @CreationTimestamp
    private Date createdDate;

    private Integer upVotes;
    private Integer downVotes;

    @ManyToOne
    private Comment comment;

    @PrePersist
    public void setNNoOfVotes() {
        upVotes = 0;
        downVotes = 0;
    }


}
