package com.example.agaseke.service.implementation;

import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Forum;
import com.example.agaseke.repository.CommentRepository;
import com.example.agaseke.service.inter.CommentInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CommentImplementation implements CommentInterface {

    @Autowired
    private CommentRepository commentRepository;

    @Override
    public Page<Comment> getAllComments(String title, Pageable pageable) {
        Specification<Comment> spec = Specification.where(null);

        if (title != null && !title.isEmpty()) {
            spec = spec.and(com.example.agaseke.specification.CommentSpecification.hasTitle(title));
        }

        return commentRepository.findAll(spec, pageable);
    }

    @Override
    public Comment getCommentById(UUID id) {
        return commentRepository.findById(id).orElse(null);
    }

    @Override
    public void saveComment(Comment comment) {
        commentRepository.save(comment);
    }

    @Override
    public void deleteComment(UUID id) {
        commentRepository.deleteById(id);

    }

    @Override
    public void updateComment(Comment comment) {
        commentRepository.save(comment);
    }

    @Override
    public Page<Comment> getCommentByForumId(Forum forum, Pageable pageable) {

        return commentRepository.findCommentByForum(forum, pageable);
    }
}
