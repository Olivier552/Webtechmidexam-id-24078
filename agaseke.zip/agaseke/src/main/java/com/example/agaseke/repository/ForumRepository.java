package com.example.agaseke.repository;
import com.example.agaseke.enums.EStatus;
import com.example.agaseke.model.Forum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface ForumRepository extends JpaRepository<Forum, UUID>, JpaSpecificationExecutor<Forum> {
    List<Forum> findByCreatedDateBetween(Date startDate, Date endDate);
    long countByStatus(EStatus status);
}
