package com.example.agaseke.enums;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class  DateChecker {
     public static void main(String[] args) {
         LocalDateTime today = LocalDateTime.now();
         LocalDateTime tomorrow = LocalDateTime.now().minusDays(7);
         System.out.println(tomorrow);
    }
}
