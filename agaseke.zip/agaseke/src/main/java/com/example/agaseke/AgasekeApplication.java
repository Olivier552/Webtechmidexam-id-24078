package com.example.agaseke;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgasekeApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgasekeApplication.class, args);
    }

}
