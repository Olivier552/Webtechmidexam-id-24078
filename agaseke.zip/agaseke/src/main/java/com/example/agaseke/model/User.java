//package com.example.agaseke.model;
//
//
//import jakarta.persistence.*;
//import lombok.Data;
//
//import java.util.UUID;
////import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
////import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//
//@Data
//@Entity
//public class User {
//    @Id
//    @GeneratedValue(strategy = GenerationType.UUID)
//    private UUID userID;
//    private String names;
//    private String email;
//    private String password;
//    private String role;
//    private String village;
//
//
////    @PrePersist
////    public void prePersist() {
////        this.password = new BCryptPasswordEncoder().encode(this.password);
////    }
//}
