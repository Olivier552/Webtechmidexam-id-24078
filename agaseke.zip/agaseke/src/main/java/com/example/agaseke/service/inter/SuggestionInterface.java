package com.example.agaseke.service.inter;

import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Suggestion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface SuggestionInterface {
    Page<Suggestion> getAllSuggestions(String title, Pageable pageable);
    Suggestion getSuggestionById(UUID id);
    void saveSuggestion(Suggestion suggestion);
    void deleteSuggestion(UUID id);
    void updateSuggestion(Suggestion suggestion);
    Page<Suggestion> getSuggestionsByComment(Comment comment, Pageable pageable);
}


