//package com.example.agaseke.service.implementation;
//
//import com.example.agaseke.model.User;
//import com.example.agaseke.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class UserImplementation {
//
//    private final UserRepository userRepository;
//    private final BCryptPasswordEncoder bCryptPasswordEncoder;
//
//    @Autowired
//    public UserImplementation(UserRepository userRepository, BCryptPasswordEncoder bCryptPasswordEncoder) {
//        this.userRepository = userRepository;
//        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
//    }
//
//    public void saveUser(User user) {
//        if (user.getPassword() != null) {
//            user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
//        }
//        userRepository.save(user);
//    }
//
//    public User findByEmail(String email) {
//        return userRepository.findByEmail(email).orElse(null);
//    }
//
//    public List<User> findAll() {
//        return userRepository.findAll();
//    }
//}
