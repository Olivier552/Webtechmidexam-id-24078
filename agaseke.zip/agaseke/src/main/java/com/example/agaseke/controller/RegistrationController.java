package com.example.agaseke.controller;

import com.example.agaseke.model.MyUser;
import com.example.agaseke.model.MyUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RegistrationController {

    @Autowired
    private MyUserRepository myUserRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

     @GetMapping("/signups")
    public String showSignupForm(Model model) {
        model.addAttribute("user", new MyUser());
        return "authentication/custom_login";
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
         model.addAttribute("user", new MyUser());
         return "authentication/custom_login";
    }
    @PostMapping("/register/user")
//    public MyUser createUser(@RequestBody MyUser user) {
//        user.setPassword(passwordEncoder.encode(user.getPassword()));
//        return myUserRepository.save(user);
//    }
    public String signup(@ModelAttribute("user") MyUser user, Model model) {
        if (myUserRepository.findByUsername(user.getUsername()).isPresent()) {
            model.addAttribute("error", "Email already exists");
            return "redirect:/login";
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        myUserRepository.save(user);
        return "authentication/custom_login";
    }
}
