package com.example.agaseke.controller;

import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Forum;
import com.example.agaseke.service.inter.CommentInterface;
import com.example.agaseke.service.inter.ForumInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/comments")
public class CommentController {

    @Autowired
    private CommentInterface commentService;

    @Autowired
    private ForumInterface forumService;
    @GetMapping
    public String getAllComments(
            @RequestParam(required = false) String title,
            Pageable pageable,
            Model model) {
        Page<Comment> commentPage = commentService.getAllComments(title, pageable);
        model.addAttribute("comments", commentPage.getContent());
        model.addAttribute("page", commentPage);
        model.addAttribute("title", title);
        return "comments/list";  // Changed view name to "comments-list"
    }
    @GetMapping("/{id}")
    public String getAllCommentsbyForum(
            @RequestParam(required = false) String title,
            @PathVariable("id") Forum forum,
            Pageable pageable,
            Model model) {
        Page<Comment> commentPage = commentService.getCommentByForumId(forum, pageable);
        model.addAttribute("forum", forum);
        model.addAttribute("comments", commentPage.getContent());
        model.addAttribute("page", commentPage);
        model.addAttribute("title", title);
        return "comments/forum-comment";

        // Changed view name to "comments-list"
    }
    @GetMapping("/new/{id}")
    public String showNewCommentFormFor(Model model, @PathVariable("id") Forum forumId) {
        model.addAttribute("comment", new Comment());
        model.addAttribute("forum", forumId);
        return "comments/forum-comment-form";
    }
    @GetMapping("/new")
    public String showNewCommentForm(Model model)
                                      {
        List<Forum> forum = forumService.getListOfForums();
        model.addAttribute("comment", new Comment());
        model.addAttribute("forum", forum);
        return "comments/form";
    }

    @PostMapping
    public String saveComment(@ModelAttribute("comment") Comment comment,
                              @RequestParam(value = "forumId") Forum forumId) {
        comment.setForum(forumId);
        commentService.saveComment(comment);
        return "redirect:/forums";
    }

    @GetMapping("/edit/{id}")
    public String showEditCommentForm(@PathVariable("id") UUID id, Model model) {
        Comment comment = commentService.getCommentById(id);
        if (comment != null) {
            model.addAttribute("comment", comment);
            return "comments/form";
        } else {
            return "redirect:/comments";
        }
    }

    @PostMapping("/update/{id}")
    public String updateComment(@PathVariable("id") UUID id, @ModelAttribute("comment") Comment comment) {
        comment.setId(id);
        commentService.updateComment(comment);
        return "redirect:/comments";
    }

    @GetMapping("/delete/{id}")
    public String deleteComment(@PathVariable("id") UUID id) {
        commentService.deleteComment(id);
        return "redirect:/comments";
    }
}
