package com.example.agaseke.enums;

public enum EStatus {
    PENDING,
    APPROVED,
    DENIED;
}
