package com.example.agaseke.model;

import com.example.agaseke.enums.EStatus;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedDate;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Data
public class Forum {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID forumID;
    private String title;
    private String content;
    @CreationTimestamp
    private Date createdDate;
    @Enumerated(EnumType.STRING)
    private EStatus status;


}
