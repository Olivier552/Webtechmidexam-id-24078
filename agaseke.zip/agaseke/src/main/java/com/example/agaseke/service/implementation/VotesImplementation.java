package com.example.agaseke.service.implementation;

import com.example.agaseke.model.Votes;
import com.example.agaseke.repository.VotesRepository;
import com.example.agaseke.service.inter.VotesInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class VotesImplementation implements VotesInterface {

    @Autowired
    VotesRepository votesRepository;

    @Override
    public List<Votes> getAllVote() {
        return (List<Votes>) votesRepository.findAll();
    }

    @Override
    public void saveVotes() {

    }
}
