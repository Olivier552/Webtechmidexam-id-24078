package com.example.agaseke.specification;

import com.example.agaseke.model.Comment;
import org.springframework.data.jpa.domain.Specification;

public class CommentSpecification {

    public static Specification<Comment> hasTitle(String title) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.like(root.get("content"), "%" + title + "%");
    }

    // Add more filtering methods as needed
}
