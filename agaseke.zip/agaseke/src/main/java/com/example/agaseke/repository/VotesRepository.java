package com.example.agaseke.repository;

import com.example.agaseke.model.Forum;
import com.example.agaseke.model.MyUser;
import com.example.agaseke.model.Votes;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.UUID;

public interface VotesRepository extends CrudRepository<Votes, UUID> {
    List<Votes> findVotesByForum(Forum forum);
    List<Votes> findVotesByUser(MyUser user);
}
