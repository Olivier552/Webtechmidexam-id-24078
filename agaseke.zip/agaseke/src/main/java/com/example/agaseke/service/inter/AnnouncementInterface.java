package com.example.agaseke.service.inter;

import com.example.agaseke.model.Announcement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public interface AnnouncementInterface {
    List<Announcement> getListOfAnnouncements();
    Page<Announcement> getAllAnnouncements(String title, Pageable pageable);
    Announcement getAnnouncementById(UUID id);
    void saveAnnouncement(Announcement announcement);
    void deleteAnnouncement(UUID id);
    void updateAnnouncement(Announcement announcement);
    List<Announcement> getAnnouncementsOneWeekOld();
}

