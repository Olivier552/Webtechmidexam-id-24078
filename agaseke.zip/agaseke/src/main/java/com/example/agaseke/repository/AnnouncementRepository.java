package com.example.agaseke.repository;

import com.example.agaseke.model.Announcement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface AnnouncementRepository extends JpaRepository<Announcement, UUID> {
    Page<Announcement> findAll(Specification<Announcement> spec, Pageable pageable);
    List<Announcement> findAnnouncementByPublishDateBetween(LocalDateTime startDate, LocalDateTime endDate);
}
