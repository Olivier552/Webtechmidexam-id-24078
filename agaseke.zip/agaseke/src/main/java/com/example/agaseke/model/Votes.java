package com.example.agaseke.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.UUID;
@Entity
@Data
public class Votes {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private int upVotes;
    private int downVotes;
    @ManyToOne
    private MyUser user;
    @ManyToOne
    private Forum forum;

    @PrePersist
    public void setNNoOfVotes() {
        upVotes = 0;
        downVotes = 0;
    }
}
