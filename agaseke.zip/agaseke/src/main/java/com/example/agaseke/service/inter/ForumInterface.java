package com.example.agaseke.service.inter;

import com.example.agaseke.enums.EStatus;
import com.example.agaseke.model.Forum;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface ForumInterface {
    List<Forum> getListOfForums();
    Page<Forum> getAllForums(String title, Pageable pageable);
    Forum getForumById(UUID id);
    void saveForum(Forum forum);
    void deleteForum(UUID id);
    void updateForum(Forum forum);
    long countByStatus(EStatus eStatus);
}

