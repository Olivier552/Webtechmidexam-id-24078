package com.example.agaseke.service.implementation;

import com.example.agaseke.model.Announcement;
import com.example.agaseke.repository.AnnouncementRepository;
import com.example.agaseke.service.inter.AnnouncementInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class AnnouncementImplementation implements AnnouncementInterface {

    @Autowired
    private AnnouncementRepository announcementRepository;

    @Override
    public List<Announcement> getListOfAnnouncements() {
        return announcementRepository.findAll();
    }

    @Override
    public Page<Announcement> getAllAnnouncements(String title, Pageable pageable) {
        Specification<Announcement> spec = Specification.where(null);

        if (title != null && !title.isEmpty()) {
            spec = spec.and(com.example.agaseke.specification.AnnouncementSpecification.hasTitle(title));
        }

        return announcementRepository.findAll(spec, pageable);
    }

    @Override
    public Announcement getAnnouncementById(UUID id) {
        return announcementRepository.findById(id).orElse(null);
    }

    @Override
    public void saveAnnouncement(Announcement announcement) {
        announcementRepository.save(announcement);
    }

    @Override
    public void deleteAnnouncement(UUID id) {
        announcementRepository.deleteById(id);

    }

    @Override
    public void updateAnnouncement(Announcement announcement) {
        announcementRepository.save(announcement);
    }

    @Override
    public List<Announcement> getAnnouncementsOneWeekOld() {
        LocalDateTime end = LocalDateTime.now();
        LocalDateTime start = end.minusDays(7);
        return announcementRepository.findAnnouncementByPublishDateBetween(end, start);
    }
}
