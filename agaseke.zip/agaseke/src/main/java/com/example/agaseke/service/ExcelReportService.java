// ExcelReportService.java
package com.example.agaseke.service;

import com.example.agaseke.model.Forum;
import com.example.agaseke.repository.ForumRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@Service
public class ExcelReportService {

    @Autowired
    private ForumRepository forumRepository;

    public byte[] generateExcelReport(Date startDate, Date endDate) throws IOException {
        List<Forum> forums = forumRepository.findByCreatedDateBetween(startDate, endDate);

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Forums");

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("ID");
        header.createCell(1).setCellValue("Title");
        header.createCell(2).setCellValue("Content");
        header.createCell(3).setCellValue("Created Date");
        header.createCell(4).setCellValue("Status");

        int rowNum = 1;
        for (Forum forum : forums) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(forum.getForumID().toString());
            row.createCell(1).setCellValue(forum.getTitle());
            row.createCell(2).setCellValue(forum.getContent());
            row.createCell(3).setCellValue(forum.getCreatedDate().toString());
            row.createCell(4).setCellValue(forum.getStatus().toString());
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        return outputStream.toByteArray();
    }
}
