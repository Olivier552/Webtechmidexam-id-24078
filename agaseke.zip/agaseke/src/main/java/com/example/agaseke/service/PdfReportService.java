// PdfReportService.java
package com.example.agaseke.service;

import com.example.agaseke.model.Forum;
import com.example.agaseke.repository.ForumRepository;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PdfReportService {

    @Autowired
    private ForumRepository forumRepository;

    public byte[] generatePdfReport(Date startDate, Date endDate) throws JRException, IOException {
        List<Forum> forums = forumRepository.findByCreatedDateBetween(startDate, endDate);
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(forums);

        InputStream reportStream = new ClassPathResource("reports/forum_report.jrxml").getInputStream();
        JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("createdBy", "Your Company Name");

        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
        return JasperExportManager.exportReportToPdf(jasperPrint);
    }
}
