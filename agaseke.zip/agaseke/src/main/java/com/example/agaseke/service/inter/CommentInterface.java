package com.example.agaseke.service.inter;

import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Forum;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface CommentInterface {
    Page<Comment> getAllComments(String title, Pageable pageable);
    Comment getCommentById(UUID id);
    void saveComment(Comment comment);
    void deleteComment(UUID id);
    void updateComment(Comment comment);
    public Page<Comment> getCommentByForumId(Forum forum,  Pageable pageable);

    }


