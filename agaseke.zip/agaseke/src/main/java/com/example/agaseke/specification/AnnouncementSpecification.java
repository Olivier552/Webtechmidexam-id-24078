package com.example.agaseke.specification;

import com.example.agaseke.model.Announcement;
import org.springframework.data.jpa.domain.Specification;

public class AnnouncementSpecification {

    public static Specification<Announcement> hasTitle(String title) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.like(root.get("Title"), "%" + title + "%");
    }

    // Add more filtering methods as needed
}
