package com.example.agaseke.specification;

import com.example.agaseke.model.Suggestion;
import org.springframework.data.jpa.domain.Specification;

public class SuggestionSpecification {

    public static Specification<Suggestion> hasTitle(String title) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.like(root.get("content"), "%" + title + "%");
    }

}
