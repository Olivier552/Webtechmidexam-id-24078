package com.example.agaseke.service.implementation;

import com.example.agaseke.enums.EStatus;
import com.example.agaseke.model.Forum;
import com.example.agaseke.repository.ForumRepository;
import com.example.agaseke.service.inter.ForumInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ForumImplementation implements ForumInterface {

    @Autowired
    private ForumRepository forumRepository;

    @Override
    public List<Forum> getListOfForums() {
        return forumRepository.findAll();
    }

    @Override
    public Page<Forum> getAllForums(String title, Pageable pageable) {
        Specification<Forum> spec = Specification.where(null);

        if (title != null && !title.isEmpty()) {
            spec = spec.and(com.example.agaseke.specification.ForumSpecification.hasTitle(title));
        }

        return forumRepository.findAll(spec, pageable);
    }

    @Override
    public Forum getForumById(UUID id) {
        return forumRepository.findById(id).orElse(null);
    }

    @Override
    public void saveForum(Forum forum) {
        forumRepository.save(forum);
    }

    @Override
    public void deleteForum(UUID id) {
        forumRepository.deleteById(id);

    }

    @Override
    public void updateForum(Forum forum) {
        forumRepository.save(forum);
    }

    @Override
    public long countByStatus(EStatus eStatus) {
        return forumRepository.countByStatus(eStatus);
    }
}
