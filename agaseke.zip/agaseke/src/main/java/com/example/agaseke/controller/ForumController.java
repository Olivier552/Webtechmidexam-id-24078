package com.example.agaseke.controller;

import com.example.agaseke.enums.EStatus;
import com.example.agaseke.model.Forum;
import com.example.agaseke.repository.ForumRepository;
import com.example.agaseke.service.ExcelReportService;
import com.example.agaseke.service.PdfReportService;
import com.example.agaseke.service.inter.ForumInterface;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/forums")
public class ForumController {

    @Autowired
    private ForumInterface forumService;

    @GetMapping
    public String getAllForums(
            @RequestParam(required = false) String title,
            Pageable pageable,
            Model model) {
        Page<Forum> forumPage = forumService.getAllForums(title, pageable);
        model.addAttribute("forums", forumPage.getContent());
        model.addAttribute("page", forumPage);
        model.addAttribute("title", title);
        return "forums/list";  // Changed view name to "forums-list"
    }

    @GetMapping("/new")
    public String showNewForumForm(Model model) {
        model.addAttribute("forum", new Forum());
        return "forums/form";
    }

    @PostMapping
    public String saveForum(@ModelAttribute("forum") Forum forum) {
        forumService.saveForum(forum);
        return "redirect:/forums";
    }

    @GetMapping("/edit/{id}")
    public String showEditForumForm(@PathVariable("id") UUID id, Model model) {
        Forum forum = forumService.getForumById(id);
        if (forum != null) {
            model.addAttribute("forum", forum);
            return "forums/form";
        } else {
            return "redirect:/forums";
        }
    }

    @PostMapping("/update/{id}")
    public String updateForum(@PathVariable("id") UUID id, @ModelAttribute("forum") Forum forum) {
        forum.setForumID(id);
        forumService.updateForum(forum);
        return "redirect:/forums";
    }

    @GetMapping("/delete/{id}")
    public String deleteForum(@PathVariable("id") UUID id) {
        forumService.deleteForum(id);
        return "redirect:/forums";
    }

    @Autowired
    private PdfReportService pdfReportService;

    @Autowired
    private ExcelReportService excelReportService;

    // Other existing endpoints

    @GetMapping("/reprt")
    public String getAllreports(
            @RequestParam(required = false) String title,
            Pageable pageable,
            Model model) {
        Page<Forum> forumPage = forumService.getAllForums(title, pageable);
        model.addAttribute("forums", forumPage.getContent());
        model.addAttribute("page", forumPage);
        model.addAttribute("title", title);
        return "forums/forumReport";  // Changed view name to "forums-list"
    }

    @GetMapping("/report")
    public String showReportPage(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate,
            Model model,
            String title,
            Pageable pageable) {
        Page<Forum> forumPage = forumService.getAllForums(title, pageable);
        model.addAttribute("forums", forumPage.getContent());
        model.addAttribute("page", forumPage);
        model.addAttribute("title", title);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        return "forums/forumReport";
    }

    @GetMapping("/report/pdf")
    public String downloadPdfReport(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate,
            Model model,
            String title,
            Pageable pageable) throws JRException, IOException {

        byte[] pdfBytes = pdfReportService.generatePdfReport(startDate, endDate);
        String base64Pdf = Base64.getEncoder().encodeToString(pdfBytes);
        Page<Forum> forumPage = forumService.getAllForums(title, pageable);
        model.addAttribute("forums", forumPage.getContent());
        model.addAttribute("page", forumPage);
        model.addAttribute("title", title);
        model.addAttribute("reportType", "PDF");
        model.addAttribute("reportData", base64Pdf);
        return "forums/forumReport";
    }

    @GetMapping("/report/excel")
    public String downloadExcelReport(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate,
            Model model,
            String title,
            Pageable pageable) throws IOException {

        byte[] excelBytes = excelReportService.generateExcelReport(startDate, endDate);
        String base64Excel = Base64.getEncoder().encodeToString(excelBytes);
        Page<Forum> forumPage = forumService.getAllForums(title, pageable);
        model.addAttribute("forums", forumPage.getContent());
        model.addAttribute("page", forumPage);
        model.addAttribute("title", title);
        model.addAttribute("reportType", "Excel");
        model.addAttribute("reportData", base64Excel);
        return "forums/forumReport";
    }


}
