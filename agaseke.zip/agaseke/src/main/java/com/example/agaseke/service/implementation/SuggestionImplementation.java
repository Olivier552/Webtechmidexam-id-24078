package com.example.agaseke.service.implementation;

import com.example.agaseke.model.Comment;
import com.example.agaseke.model.Suggestion;
import com.example.agaseke.repository.SuggestionRepository;
import com.example.agaseke.service.inter.SuggestionInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class SuggestionImplementation implements SuggestionInterface {

    @Autowired
    private SuggestionRepository suggestionRepository;

    @Override
    public Page<Suggestion> getAllSuggestions(String title, Pageable pageable) {
        Specification<Suggestion> spec = Specification.where(null);

        if (title != null && !title.isEmpty()) {
            spec = spec.and(com.example.agaseke.specification.SuggestionSpecification.hasTitle(title));
        }

        return suggestionRepository.findAll(spec, pageable);
    }

    @Override
    public Page<Suggestion> getSuggestionsByComment(Comment comment, Pageable pageable) {


        return suggestionRepository.findSuggestionsByComment(comment, pageable);
    }

    @Override
    public Suggestion getSuggestionById(UUID id) {
        return suggestionRepository.findById(id).orElse(null);
    }

    @Override
    public void saveSuggestion(Suggestion suggestion) {
        suggestionRepository.save(suggestion);
    }

    @Override
    public void deleteSuggestion(UUID id) {
        suggestionRepository.deleteById(id);

    }

    @Override
    public void updateSuggestion(Suggestion suggestion) {
        suggestionRepository.save(suggestion);
    }
}
