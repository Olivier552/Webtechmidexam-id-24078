//package com.example.agaseke.config;
//
//import com.example.agaseke.service.CustomUserDetailsService;
//import com.example.agaseke.service.implementation.UserImplementation;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationProvider;
//import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//    @Autowired
//    CustomUserDetailsService customUserDetailsService;
//
//    @Autowired
//    UserImplementation userImplementation;
//
//    private final BCryptPasswordEncoder bCryptPasswordEncoder;
//
//    public SecurityConfig(UserImplementation userImplementation, BCryptPasswordEncoder bCryptPasswordEncoder) {
//        this.userImplementation = userImplementation;
//        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
//    }
//
//    @Bean
//    public AuthenticationProvider authenticationProvider() {
//        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
////        userImplementation.findAll().forEach(user -> {
////            if (user.getPassword() != null) {
////                provider.setUserDetailsService(org.springframework.security.core.userdetails.User.withUsername(user.getEmail())
////                        .password(user.getPassword())
////                        .roles(user.getRole().toUpperCase())
////                        .build());
////            }
////        });
////        return provider;
//        provider.setUserDetailsService(customUserDetailsService);
//        provider.setPasswordEncoder(bCryptPasswordEncoder);
//        return provider;
//    }
//
//    @Bean
//    public UserDetailsService userDetailsService() {
//        return customUserDetailsService;
//    }
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//
//
//                .authorizeHttpRequests((requests) -> requests
//                        .requestMatchers("/forums/**").hasAnyRole("CITIZEN", "VILLAGE_CHIEF", "SECTOR_SECRETARY", "EXECUTIVE_SECRETARY")
//                        .requestMatchers("/users/signups").permitAll()
//                        .requestMatchers("/users/**").permitAll()
//                        .requestMatchers("/forums/**").permitAll()
//                        .requestMatchers("/suggestions/**").permitAll()
//                        .requestMatchers("comments/**").permitAll()
//                        .anyRequest().authenticated()
//                )
//                .formLogin((form) -> form
//                        .loginPage("/users/login")
//                        .permitAll()
//                        .defaultSuccessUrl("/forums")
//                )
//                .logout((logout) -> logout.permitAll());
//
//        return http.build();
//    }
//}
