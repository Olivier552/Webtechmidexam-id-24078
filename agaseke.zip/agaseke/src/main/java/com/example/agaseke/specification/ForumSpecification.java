package com.example.agaseke.specification;

import com.example.agaseke.model.Forum;
import org.springframework.data.jpa.domain.Specification;

public class ForumSpecification {

    public static Specification<Forum> hasTitle(String title) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.like(root.get("title"), "%" + title + "%");
    }

    // Add more filtering methods as needed
}
