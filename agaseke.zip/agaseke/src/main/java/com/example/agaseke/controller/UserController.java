//package com.example.agaseke.controller;
//
//import com.example.agaseke.model.User;
//import com.example.agaseke.service.implementation.UserImplementation;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//@RequestMapping("/users")
//public class UserController {
//
//    @Autowired
//    private UserImplementation userImplementation;
//
//
//
//    @PostMapping("/signup")
//    public String signup(@ModelAttribute("user") User user, Model model) {
//        if (userImplementation.findByEmail(user.getEmail()) != null) {
//            model.addAttribute("error", "Email already exists");
//            return "authentication/login";
//        }
//        userImplementation.saveUser(user);
//        return "authentication/login";
//    }
//
//