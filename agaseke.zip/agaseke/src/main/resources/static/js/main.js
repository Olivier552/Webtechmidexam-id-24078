// document.addEventListener("DOMContentLoaded", () => {
//     const forumForm = document.getElementById("forum-form");
//     const forumTableBody = document.getElementById("forumTable").querySelector("tbody");
//     const statusChartCtx = document.getElementById("statusChart").getContext("2d");
//
//     let forums = [];
//
//     forumForm.addEventListener("submit", (event) => {
//         event.preventDefault();
//         const forum = {
//             forumId: document.getElementById("forumId").value,
//             title: document.getElementById("title").value,
//             content: document.getElementById("content").value,
//             createdDate: document.getElementById("createdDate").value,
//             status: document.getElementById("status").value
//         };
//         forums.push(forum);
//         renderTable(forums);
//         updateChart();
//         forumForm.reset();
//     });
//
//     document.getElementById("filterDate").addEventListener("input", (event) => {
//         const filterDate = event.target.value;
//         const filteredForums = forums.filter(forum => forum.createdDate === filterDate);
//         renderTable(filteredForums);
//     });
//
//     const renderTable = (data) => {
//         forumTableBody.innerHTML = "";
//         data.forEach(forum => {
//             const row = forumTableBody.insertRow();
//             row.insertCell(0).textContent = forum.forumId;
//             row.insertCell(1).textContent = forum.title;
//             row.insertCell(2).textContent = forum.content;
//             row.insertCell(3).textContent = forum.createdDate;
//             row.insertCell(4).textContent = forum.status;
//         });
//     };
//
//     const updateChart = () => {
//         const statusCounts = forums.reduce((counts, forum) => {
//             counts[forum.status] = (counts[forum.status] || 0) + 1;
//             return counts;
//         }, {});
//
//         const chartData = {
//             labels: ["PENDING", "APPROVED", "DENIED"],
//             datasets: [{
//                 label: "Forum Status",
//                 data: [
//                     statusCounts["PENDING"] || 0,
//                     statusCounts["APPROVED"] || 0,
//                     statusCounts["DENIED"] || 0
//                 ],
//                 backgroundColor: ["#FFCE56", "#36A2EB", "#FF6384"]
//             }]
//         };
//
//         new Chart(statusChartCtx, {
//             type: "bar",
//             data: chartData,
//             options: {
//                 responsive: true,
//                 scales: {
//                     y: {
//                         beginAtZero: true
//                     }
//                 }
//             }
//         });
//     };
//
//     window.downloadPdf = () => {
//         const { jsPDF } = window.jspdf;
//         const doc = new jsPDF();
//         doc.autoTable({ html: '#forumTable' });
//         doc.save('forums_report.pdf');
//     };
//
//     window.downloadExcel = () => {
//         const ws = XLSX.utils.json_to_sheet(forums);
//         const wb = XLSX.utils.book_new();
//         XLSX.utils.book_append_sheet(wb, ws, "Forums");
//         XLSX.writeFile(wb, "forums_report.xlsx");
//     };
// });
document.addEventListener("DOMContentLoaded", () => {
    const forumTableBody = document.getElementById("forumTable").querySelector("tbody");

    window.downloadPdf = () => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Define the columns we want and their titles
        const columns = [  "Title", "Content", "Created Date", "Status"];
        const data = [];

        // Grab the data from the table
        forumTableBody.querySelectorAll("tr").forEach((row) => {
            const rowData = [];
            row.querySelectorAll("td").forEach((cell) => {
                rowData.push(cell.textContent);
            });
            data.push(rowData);
        });

        // Create the PDF
        doc.autoTable({
            head: [columns],
            body: data,
        });

        // Save the PDF
        doc.save("forums_report.pdf");
    };

    window.downloadExcel = () => {
        const data = [];

        // Define the columns we want and their titles
        const columns = ["Title", "Content", "Created Date", "Status"];
        data.push(columns);

        // Grab the data from the table
        forumTableBody.querySelectorAll("tr").forEach((row) => {
            const rowData = [];
            row.querySelectorAll("td").forEach((cell) => {
                rowData.push(cell.textContent);
            });
            data.push(rowData);
        });

        // Create the Excel file
        const ws = XLSX.utils.aoa_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Forums");

        // Save the Excel file
        XLSX.writeFile(wb, "forums_report.xlsx");
    };
});
