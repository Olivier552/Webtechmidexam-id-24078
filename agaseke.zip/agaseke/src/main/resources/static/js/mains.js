document.addEventListener('DOMContentLoaded', function() {
    // Fetch forum statistics
    fetch('/forums/stats')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('forumStatusChart').getContext('2d');
            const forumStatusChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Pending', 'Approved', 'Denied'],
                    datasets: [{
                        label: '# of Forums',
                        data: [data.pending, data.approved, data.denied],
                        backgroundColor: [
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(255, 99, 132, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 99, 132, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error fetching forum statistics:', error));
});
